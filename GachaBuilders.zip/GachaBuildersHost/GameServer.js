var room = require('./room.js');

function gameServer(spec, my) {
    var ajax = require('ajax-lib')
    var app = spec.httpServer;
    var logLevel = spec.logLevel || 1;
    var io = require('socket.io').listen(app, {
        'log level' : logLevel
    });

    var mainRoom = room();

    var collback = function (text) {
        io.sockets.in(0).emit('BattleLog', text);
    };

    var hideEquip = function(){
      io.sockets.in(0).emit('HideEquip');
    };

    var onBattle = function () {
        io.sockets.in(0).emit('OnBattle', mainRoom.doBattle(collback));
    };


    //mainRoom.join('t');
    //ajax.get('http://localhost:5900/GachaBuildersHost/acceGacha.php', function (err, json) {
    //
    //    var roomId = 0;
    //    var name = 't';
    //    var eq = {
    //        name: name,
    //        val: json.body
    //    };
    //    mainRoom.setWeapon(eq);
    //    io.sockets.in(roomId).emit('ChangeWeapon', eq);
    //    console.log('ChangeWeapon');
    //});

    io.sockets.on('connection', function (socket) {

        socket.on('EnterRoom', function (data) {
            if (mainRoom.isStartGame()) {
                console.log('enterroom over');
                return;
            }
            console.log('enterroom');
            var roomId = data.roomId;
            var name = data.name;
            var loginInfo = {
                roomId : roomId,
                name : name
            };
            console.log(name);
            socket.loginInfo = {
                roomId: roomId,
                name: name
            };
            mainRoom.join(name);
            socket.join(roomId);
            if (mainRoom.isStartGame()) {
                var ret = {
                    players: mainRoom.getPlayers()
                };
                io.sockets.in(roomId).emit('GameStart', ret);

                setTimeout(hideEquip, 1000 * 60);
                setTimeout(onBattle, 1000 * 90);
            }

        });

        socket.on('GachaMonster', function () {
            ajax.get('http://localhost:5900/GachaBuildersHost/monsterGacha.php', function (err, json) {
                var roomId = socket.loginInfo.roomId;
                var name = socket.loginInfo.name;
                var eq = {
                    name: name,
                    val: JSON.parse(json.body)
                };
                mainRoom.setMonster(eq);
                io.sockets.in(roomId).emit('ChangeMonster', eq);
            });
        });
        socket.on('GachaHelm', function () {
            ajax.get('http://localhost:5900/GachaBuildersHost/helmGacha.php', function (err, json) {

                var roomId = socket.loginInfo.roomId;
                var name = socket.loginInfo.name;
                var eq = {
                    name: name,
                    val: JSON.parse(json.body)
                };
                mainRoom.setHelm(eq);
                io.sockets.in(roomId).emit('ChangeHelm', eq);
            });
        });
        socket.on('GachaArmor', function () {
            ajax.get('http://localhost:5900/GachaBuildersHost/armorGacha.php', function (err, json) {

                var roomId = socket.loginInfo.roomId;
                var name = socket.loginInfo.name;
                var eq = {
                    name: name,
                    val: JSON.parse(json.body)
                };
                mainRoom.setArmor(eq);
                io.sockets.in(roomId).emit('ChangeArmor', eq);
            });
        });
        socket.on('GachaBoots',function(){
            ajax.get('http://localhost:5900/GachaBuildersHost/bootsGacha.php', function (err, json) {

                var roomId = socket.loginInfo.roomId;
                var name = socket.loginInfo.name;
                var eq = {
                    name: name,
                    val: JSON.parse(json.body)
                };
                mainRoom.setBoots(eq);
                io.sockets.in(roomId).emit('ChangeBoots', eq);
            });
        });
        socket.on('GachaWeapon',function(){

            ajax.get('http://localhost:5900/GachaBuildersHost/weaponGacha.php', function (err, json) {

                var roomId = socket.loginInfo.roomId;
                var name = socket.loginInfo.name;
                var eq = {
                    name: name,
                    val: JSON.parse(json.body)
                };
                mainRoom.setWeapon(eq);
                io.sockets.in(roomId).emit('ChangeWeapon', eq);
            });
        });
        socket.on('GachaShield',function(){
            ajax.get('http://localhost:5900/GachaBuildersHost/shieldGacha.php', function (err, json) {

                var roomId = socket.loginInfo.roomId;
                var name = socket.loginInfo.name;
                var eq = {
                    name: name,
                    val: JSON.parse(json.body)
                };
                mainRoom.setShield(eq);
                io.sockets.in(roomId).emit('ChangeShield', eq);
            });
        });
        socket.on('GachaAcce', function () {
            ajax.get('http://localhost:5900/GachaBuildersHost/acceGacha.php', function (err, json) {

                var roomId = socket.loginInfo.roomId;
                var name = socket.loginInfo.name;
                var eq = {
                    name: name,
                    val: JSON.parse(json.body)
                };
                mainRoom.setAccessory(eq);
                io.sockets.in(roomId).emit('ChangeAcce', eq);
            });
        });

        socket.on('Battle',function(){
                var roomId = socket.loginInfo.roomId;
                if(mainRoom.isStart()){

                    var ret = mainRoom.doBattle(collback);
                    io.sockets.in(roomId).emit('OnBattle', ret);
                }
        });

        socket.on('disconnect',function(data){
            //var roomId = socket.loginInfo.roomId;
            socket.leave(0);
            var clients = io.sockets.clients(0);
                if(clients.length === 0) {
                    mainRoom = room();
                    console.log('room reset');
                } else {
                    //clients.disconnect();
                    //for (var i in clients) {
                    //    console.log(i);
                    //   clients.disconnect();
                    //}
                }
        });
    });

    return io;
};

module.exports = gameServer;
