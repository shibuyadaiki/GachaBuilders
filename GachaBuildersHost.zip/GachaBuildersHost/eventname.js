const HeadEquipEventName='head_event';
const BodyEquipEventname='body_event';
const SwordEquipEventName='sword_event';
const ShieldEquipEventName='shield_event';
const FootEquipEventName='foot_event';
const RegEquipEventName='reg_event';
//規定イベント
const Connect='connect';
const Connecting='connectiong';
const Disconnect='disconnect';
const ConnectFaild='connect_faild';
const Error='error';
const Reconnect_faild='reconnect_faild';
const Reconnect='recconect';
const Recconecting='recconecting';
